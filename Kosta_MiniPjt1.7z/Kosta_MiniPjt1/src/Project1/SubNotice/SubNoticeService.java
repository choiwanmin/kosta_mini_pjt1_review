package Project1.SubNotice;

import java.util.Scanner;

public class SubNoticeService {
	private SubNoticeDao dao;
	
	public SubNoticeService() {
		dao = new SubNoticeDao();
	}
	
	
	
	//지원자 등록
	
//	public void addSub(Scanner sc) {
//		System.out.println("=== 글작성 ===");
//		System.out.print("title:");
//		sc.nextLine();
//		String title = sc.nextLine();
//		System.out.print("content:");
//		String content = sc.nextLine();
//		dao.insert(new Board(0, MemService.loginId, null, content, title));
//	}
	
	//등록된 지원자 삭제
	
	
	
	//등록된 지원자 현황 출력 
	
}
